// PaVa-Vak Main Server
// Complete Express + Socket.io server with all features

require('dotenv').config();
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const session = require('express-session');
const helmet = require('helmet');
const compression = require('compression');
const morgan = require('morgan');
const cors = require('cors');
const path = require('path');
const { PrismaClient } = require('@prisma/client');

// Initialize Prisma
const prisma = new PrismaClient();

// Initialize Express
const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: process.env.DOMAIN || 'http://localhost:3000',
    credentials: true
  },
  pingInterval: parseInt(process.env.WS_PING_INTERVAL) || 25000,
  pingTimeout: parseInt(process.env.WS_PING_TIMEOUT) || 60000
});

// Middleware
app.use(helmet({
  contentSecurityPolicy: process.env.HELMET_CSP_ENABLED === 'true',
  hsts: process.env.HELMET_HSTS_ENABLED === 'true'
}));
app.use(compression());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// CORS (only in development)
if (process.env.ENABLE_CORS === 'true') {
  app.use(cors({
    origin: process.env.DOMAIN,
    credentials: true
  }));
}

// Logging
if (process.env.NODE_ENV !== 'production') {
  app.use(morgan('dev'));
} else {
  app.use(morgan('combined'));
}

// Session configuration
app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    maxAge: parseInt(process.env.SESSION_MAX_AGE) || 604800000, // 7 days
    sameSite: 'strict'
  }
}));

// Import routes
const authRoutes = require('./routes/auth');
const messageRoutes = require('./routes/messages');
const adminRoutes = require('./routes/admin');
const connectionRoutes = require('./routes/connections');
const inviteRoutes = require('./routes/invites');
const userRoutes = require('./routes/users');

// API routes
app.use('/api/auth', authRoutes);
app.use('/api/messages', messageRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/connections', connectionRoutes);
app.use('/api/invites', inviteRoutes);
app.use('/api/users', userRoutes);

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: process.env.NODE_ENV
  });
});

// Serve static files (frontend)
app.use(express.static(path.join(__dirname, '../frontend')));

// SPA fallback
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// WebSocket connection handling
const connectedUsers = new Map(); // userId -> socket.id

io.on('connection', (socket) => {
  console.log(`New WebSocket connection: ${socket.id}`);

  // Authenticate WebSocket connection
  socket.on('authenticate', async (data) => {
    try {
      const { userId, sessionToken } = data;

      // Verify session
      const session = await prisma.session.findFirst({
        where: {
          userId,
          sessionToken,
          expiresAt: { gt: new Date() }
        },
        include: { user: true }
      });

      if (!session) {
        socket.emit('auth_error', { message: 'Invalid session' });
        socket.disconnect();
        return;
      }

      // Store user connection
      socket.userId = userId;
      connectedUsers.set(userId, socket.id);

      // Join user's personal room
      socket.join(userId);

      // Update last seen
      await prisma.user.update({
        where: { id: userId },
        data: { lastSeen: new Date() }
      });

      // Notify user of successful authentication
      socket.emit('authenticated', {
        userId,
        username: session.user.username
      });

      // Broadcast online status to connections
      const connections = await prisma.connection.findMany({
        where: {
          OR: [
            { userAId: userId },
            { userBId: userId }
          ],
          isActive: true
        }
      });

      connections.forEach(conn => {
        const otherUserId = conn.userAId === userId ? conn.userBId : conn.userAId;
        io.to(otherUserId).emit('user_online', { userId });
      });

      console.log(`User ${userId} authenticated on socket ${socket.id}`);
    } catch (error) {
      console.error('Authentication error:', error);
      socket.emit('auth_error', { message: 'Authentication failed' });
      socket.disconnect();
    }
  });

  // Send message
  socket.on('send_message', async (data) => {
    try {
      const { recipientId, content, timer } = data;
      const senderId = socket.userId;

      if (!senderId) {
        socket.emit('error', { message: 'Not authenticated' });
        return;
      }

      // Verify connection exists
      const connection = await prisma.connection.findFirst({
        where: {
          OR: [
            { userAId: senderId, userBId: recipientId },
            { userAId: recipientId, userBId: senderId }
          ],
          isActive: true
        }
      });

      if (!connection) {
        socket.emit('error', { message: 'No connection with this user' });
        return;
      }

      // Create message
      const message = await prisma.message.create({
        data: {
          senderId,
          recipientId,
          content,
          sentAt: new Date()
        },
        include: {
          sender: {
            select: {
              id: true,
              username: true,
              fullName: true
            }
          }
        }
      });

      // Create timer if specified
      if (timer && timer.type !== 'KEEP_FOREVER') {
        const timerData = {
          messageId: message.id,
          timerType: timer.type
        };

        if (timer.type === 'TIMED') {
          timerData.deleteAfterSeconds = timer.seconds;
          timerData.deleteAt = new Date(Date.now() + timer.seconds * 1000);
        }

        await prisma.messageTimer.create({ data: timerData });
      }

      // Send to recipient (if online)
      io.to(recipientId).emit('new_message', {
        id: message.id,
        content: message.content,
        sender: message.sender,
        sentAt: message.sentAt,
        timer: timer || null
      });

      // Confirm to sender
      socket.emit('message_sent', {
        id: message.id,
        sentAt: message.sentAt
      });

      // Log activity
      await prisma.systemLog.create({
        data: {
          level: 'INFO',
          action: 'MESSAGE_SENT',
          message: `Message sent from ${senderId} to ${recipientId}`,
          metadata: { messageId: message.id }
        }
      });

    } catch (error) {
      console.error('Send message error:', error);
      socket.emit('error', { message: 'Failed to send message' });
    }
  });

  // Mark message as read
  socket.on('mark_read', async (data) => {
    try {
      const { messageId } = data;
      const userId = socket.userId;

      const message = await prisma.message.findFirst({
        where: {
          id: messageId,
          recipientId: userId
        }
      });

      if (message) {
        await prisma.message.update({
          where: { id: messageId },
          data: { readAt: new Date() }
        });

        // Notify sender
        io.to(message.senderId).emit('message_read', {
          messageId,
          readAt: new Date()
        });
      }
    } catch (error) {
      console.error('Mark read error:', error);
    }
  });

  // Typing indicator
  socket.on('typing', (data) => {
    const { recipientId } = data;
    io.to(recipientId).emit('user_typing', {
      userId: socket.userId
    });
  });

  // Stop typing
  socket.on('stop_typing', (data) => {
    const { recipientId } = data;
    io.to(recipientId).emit('user_stop_typing', {
      userId: socket.userId
    });
  });

  // Disconnect
  socket.on('disconnect', async () => {
    const userId = socket.userId;
    
    if (userId) {
      connectedUsers.delete(userId);

      // Update last seen
      try {
        await prisma.user.update({
          where: { id: userId },
          data: { lastSeen: new Date() }
        });

        // Broadcast offline status
        const connections = await prisma.connection.findMany({
          where: {
            OR: [
              { userAId: userId },
              { userBId: userId }
            ],
            isActive: true
          }
        });

        connections.forEach(conn => {
          const otherUserId = conn.userAId === userId ? conn.userBId : conn.userAId;
          io.to(otherUserId).emit('user_offline', { 
            userId,
            lastSeen: new Date()
          });
        });

      } catch (error) {
        console.error('Disconnect error:', error);
      }

      console.log(`User ${userId} disconnected from socket ${socket.id}`);
    }
  });
});

// Background job: Process expired timers
setInterval(async () => {
  try {
    const expiredTimers = await prisma.messageTimer.findMany({
      where: {
        deleteAt: { lte: new Date() },
        deletedFromRecipientView: false,
        timerType: 'TIMED'
      },
      include: { message: true }
    });

    for (const timer of expiredTimers) {
      // Mark message as deleted for recipient
      await prisma.message.update({
        where: { id: timer.messageId },
        data: { isDeletedByRecipient: true }
      });

      // Mark timer as executed
      await prisma.messageTimer.update({
        where: { id: timer.id },
        data: { deletedFromRecipientView: true }
      });

      // Notify recipient via WebSocket
      io.to(timer.message.recipientId).emit('message_deleted', {
        messageId: timer.messageId
      });
    }

    if (expiredTimers.length > 0) {
      console.log(`Processed ${expiredTimers.length} expired message timers`);
    }
  } catch (error) {
    console.error('Timer processing error:', error);
  }
}, 60000); // Run every minute

// Cleanup expired sessions
setInterval(async () => {
  try {
    const result = await prisma.session.deleteMany({
      where: {
        expiresAt: { lt: new Date() }
      }
    });
    
    if (result.count > 0) {
      console.log(`Cleaned up ${result.count} expired sessions`);
    }
  } catch (error) {
    console.error('Session cleanup error:', error);
  }
}, 3600000); // Run every hour

// Error handling
app.use((err, req, res, next) => {
  console.error('Error:', err);
  
  // Log error
  prisma.systemLog.create({
    data: {
      level: 'ERROR',
      action: 'SERVER_ERROR',
      message: err.message,
      metadata: {
        stack: err.stack,
        url: req.url,
        method: req.method
      }
    }
  }).catch(console.error);

  res.status(err.status || 500).json({
    error: process.env.NODE_ENV === 'production' 
      ? 'Internal server error' 
      : err.message
  });
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down gracefully...');
  
  server.close(() => {
    console.log('HTTP server closed');
  });

  await prisma.$disconnect();
  console.log('Database disconnected');
  process.exit(0);
});

// Start server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`
╔═══════════════════════════════════════╗
║                                       ║
║     PaVa-Vak Server Started! 🚀      ║
║                                       ║
║  Port: ${PORT}                          ║
║  Environment: ${process.env.NODE_ENV || 'development'}           ║
║  Domain: ${process.env.DOMAIN || 'http://localhost:3000'}
║                                       ║
╚═══════════════════════════════════════╝
  `);
});

module.exports = { app, server, io, prisma };
