// Authentication Middleware
// Protects routes and validates user sessions

const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

// Check if user is authenticated
async function isAuthenticated(req, res, next) {
  try {
    // Check session
    if (!req.session || !req.session.userId) {
      return res.status(401).json({
        error: 'Not authenticated',
        code: 'AUTH_REQUIRED'
      });
    }

    // Verify session in database
    const session = await prisma.session.findFirst({
      where: {
        userId: req.session.userId,
        sessionToken: req.session.sessionToken,
        expiresAt: { gt: new Date() }
      },
      include: {
        user: {
          select: {
            id: true,
            username: true,
            fullName: true,
            role: true,
            status: true
          }
        }
      }
    });

    if (!session) {
      req.session.destroy();
      return res.status(401).json({
        error: 'Session expired',
        code: 'SESSION_EXPIRED'
      });
    }

    // Check if user is banned
    if (session.user.status === 'BANNED') {
      return res.status(403).json({
        error: 'Account suspended',
        code: 'ACCOUNT_BANNED'
      });
    }

    // Update last activity
    await prisma.session.update({
      where: { id: session.id },
      data: { lastActivity: new Date() }
    });

    // Attach user to request
    req.user = session.user;
    next();

  } catch (error) {
    console.error('Authentication error:', error);
    res.status(500).json({
      error: 'Authentication check failed'
    });
  }
}

// Check if user is admin
function isAdmin(req, res, next) {
  if (!req.user || req.user.role !== 'ADMIN') {
    return res.status(403).json({
      error: 'Admin access required',
      code: 'ADMIN_REQUIRED'
    });
  }
  next();
}

// Check if user can access resource
async function canAccessUser(req, res, next) {
  const targetUserId = req.params.userId || req.body.userId;
  
  // Admins can access anyone
  if (req.user.role === 'ADMIN') {
    return next();
  }

  // Users can only access themselves
  if (req.user.id !== targetUserId) {
    return res.status(403).json({
      error: 'Access denied',
      code: 'ACCESS_DENIED'
    });
  }

  next();
}

// Check if users are connected (can chat)
async function areConnected(req, res, next) {
  try {
    const userId = req.user.id;
    const otherUserId = req.params.userId || req.body.recipientId;

    // Admins bypass this check
    if (req.user.role === 'ADMIN') {
      return next();
    }

    // Check if connection exists
    const connection = await prisma.connection.findFirst({
      where: {
        OR: [
          { userAId: userId, userBId: otherUserId },
          { userAId: otherUserId, userBId: userId }
        ],
        isActive: true
      }
    });

    if (!connection) {
      return res.status(403).json({
        error: 'No connection with this user',
        code: 'NOT_CONNECTED'
      });
    }

    next();

  } catch (error) {
    console.error('Connection check error:', error);
    res.status(500).json({
      error: 'Connection check failed'
    });
  }
}

module.exports = {
  isAuthenticated,
  isAdmin,
  canAccessUser,
  areConnected
};
